# Como ligar a aplicação

## A. Criar o backend Supabase
1. Cria um projeto no Supabase e guarda com segurança a palavra-passe da base de dados.
2. Em SQL Editor, executa o ficheiro `schema.sql`.
3. Em Storage, cria um bucket chamado `ad-images` e marca-o como público para as imagens dos anúncios. As políticas de upload estão no SQL.
4. Em Authentication > Providers, ativa Phone e configura um fornecedor SMS. Define as regras de OTP/telefone adequadas à tua região e testa o registo.
5. Regista a tua conta de proprietário através da app, usando o teu número. Em Authentication > Users, copia o UUID da conta.
6. No SQL Editor, cria o perfil de administrador, substituindo os valores:
   `insert into public.profiles(id, first_name, phone, is_admin) values ('UUID-REAL','Proprietário','TELEFONE-REAL',true) on conflict(id) do update set is_admin=true;`
   Se não existir perfil, este comando cria-o. Não partilhes o UUID nem os segredos em público.
7. Em Project Settings > API, copia Project URL e a chave pública `anon`/`publishable` (nunca `service_role`).
8. Abre `index.html` e substitui:
   - `SUPABASE_URL_AQUI` pela URL real
   - `SUPABASE_ANON_KEY_AQUI` pela chave pública real
9. Guarda o ficheiro.

## B. Publicar no Netlify
1. Extrai o ZIP.
2. Carrega os ficheiros do projeto para um novo site no Netlify, ou para o site existente se quiseres substituir a versão anterior.
3. Confirma que `index.html`, `manifest.webmanifest` e `sw.js` estão na raiz publicada.
4. Abre o URL HTTPS do site num telemóvel e testa:
   - registo por telefone/SMS e entrada;
   - publicar anúncio e carregar imagem;
   - aprovação com a conta do proprietário;
   - pesquisa e botão WhatsApp;
   - feedback.
5. Só anuncia o site ao público depois de concluir os testes.

## C. Limites importantes
- O pacote não pode criar o teu projeto Supabase nem publicar no teu Netlify sem a tua autorização/acesso e as credenciais correspondentes.
- Não existe pagamento automático de 500 Kz. O painel contabiliza 500 Kz por anúncio aprovado; isso não prova que recebeste dinheiro.
- Não há publicação automática em Facebook/TikTok/Instagram. O formulário apenas guarda um link opcional; automação exige APIs oficiais e autorização.
- Antes do lançamento público, adiciona política de privacidade, termos, contacto do suporte e regras de denúncia/moderação.
