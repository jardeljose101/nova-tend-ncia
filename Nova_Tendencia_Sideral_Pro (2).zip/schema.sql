-- Nova Tendência Sideral: executar no SQL Editor do Supabase.
-- Configure autenticação por telefone/SMS e crie um bucket público "ad-images".
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  first_name text,
  phone text,
  is_admin boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists public.ads (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references auth.users(id) on delete cascade,
  seller_name text not null,
  title text not null check (char_length(title) between 2 and 120),
  description text default '',
  category text not null check (category in ('TIC','Moda','Beleza','Fragrância','Serviços')),
  ad_type text not null default 'Produto' check (ad_type in ('Produto','Serviço')),
  price numeric(14,2) check (price is null or price >= 0),
  phone text not null,
  province text default '',
  municipality text default '',
  comuna text default '',
  bairro text default '',
  image_url text,
  social_url text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','deleted')),
  earned boolean not null default false,
  created_at timestamptz not null default now(),
  approved_at timestamptz
);
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(select 1 from public.profiles where id = auth.uid() and is_admin = true);
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles(id, first_name, phone, is_admin)
  values (new.id, coalesce(new.raw_user_meta_data->>'first_name',''), coalesce(new.phone,''), false)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile
after insert on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  name text default '',
  contact text default '',
  kind text not null default 'Sugestão',
  message text not null check (char_length(message) between 2 and 4000),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.ads enable row level security;
alter table public.feedback enable row level security;

drop policy if exists "profiles select own or admin" on public.profiles;
create policy "profiles select own or admin" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_admin());
drop policy if exists "profiles insert own" on public.profiles;
create policy "profiles insert own" on public.profiles for insert to authenticated
with check (id=auth.uid() and coalesce(is_admin,false)=false);
drop policy if exists "profiles update own nonadmin" on public.profiles;
create policy "profiles update own nonadmin" on public.profiles for update to authenticated
using (id=auth.uid() and is_admin=false) with check (id=auth.uid() and is_admin=false);

drop policy if exists "public reads approved ads" on public.ads;
create policy "public reads approved ads" on public.ads for select to anon, authenticated
using (status='approved' or seller_id=auth.uid() or public.is_admin());
drop policy if exists "seller creates pending ads" on public.ads;
create policy "seller creates pending ads" on public.ads for insert to authenticated
with check (seller_id=auth.uid() and status='pending' and earned=false);
drop policy if exists "admin updates ads" on public.ads;
create policy "admin updates ads" on public.ads for update to authenticated
using (public.is_admin())
with check (public.is_admin());
drop policy if exists "admin deletes ads" on public.ads;
create policy "admin deletes ads" on public.ads for delete to authenticated
using (public.is_admin());

drop policy if exists "anyone can send feedback" on public.feedback;
create policy "anyone can send feedback" on public.feedback for insert to anon, authenticated
with check (user_id is null or user_id=auth.uid());
drop policy if exists "admin reads feedback" on public.feedback;
create policy "admin reads feedback" on public.feedback for select to authenticated
using (public.is_admin());
drop policy if exists "admin deletes feedback" on public.feedback;
create policy "admin deletes feedback" on public.feedback for delete to authenticated
using (public.is_admin());

-- Create a public storage bucket named ad-images in Storage > New bucket.
-- Storage policies for authenticated sellers to upload into their own UUID folder:
drop policy if exists "seller uploads own ad images" on storage.objects;
create policy "seller uploads own ad images" on storage.objects for insert to authenticated
with check (bucket_id='ad-images' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "public reads ad images" on storage.objects;
create policy "public reads ad images" on storage.objects for select to anon, authenticated
using (bucket_id='ad-images');
drop policy if exists "seller deletes own ad images" on storage.objects;
create policy "seller deletes own ad images" on storage.objects for delete to authenticated
using (bucket_id='ad-images' and (storage.foldername(name))[1]=auth.uid()::text);

-- IMPORTANTE: depois de criar a conta do proprietário, substitua o UUID abaixo pelo auth.users.id real:
-- update public.profiles set is_admin=true where id='COLOQUE-AQUI-O-UUID-DA-CONTA-DO-DONO';
-- Criar o perfil do dono, usando o UUID real:
-- insert into public.profiles(id, first_name, phone, is_admin)
-- values ('COLOQUE-AQUI-O-UUID-DA-CONTA-DO-DONO','Proprietário','TELEFONE_DO_DONO',true)
-- on conflict(id) do update set is_admin=true;
