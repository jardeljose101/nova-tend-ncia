# Nova Tendência Sideral — pacote profissional de arranque

Este pacote é um front-end web responsivo/PWA preparado para integração com Supabase. Não é correto chamar-lhe "100% pronto para produção" antes de o proprietário criar e configurar os serviços externos e testar a segurança.

## Incluído
- `index.html`: interface responsiva, catálogo, pesquisa/categorias/localização, área de vendedor, formulário com imagem, WhatsApp, feedback e UI administrativa.
- `schema.sql`: tabelas, RLS e políticas de acesso iniciais para Supabase.
- `manifest.webmanifest` e `sw.js`: base de instalação/cache PWA.
- `netlify.toml`: publicação estática.
- `CONFIGURAR.md`: passos obrigatórios.

## Requisito de segurança
Nunca colocar a `service_role key` do Supabase no HTML. Só a URL e a chave pública `anon/publishable` podem ficar no cliente; as políticas RLS protegem dados. A função de administrador é definida na tabela `profiles`, não por uma senha escondida no JavaScript.

## Funcionalidades externas que precisam de configuração
- Projeto Supabase e credenciais reais.
- SMS/provedor para autenticação por telefone.
- Bucket `ad-images`.
- Criar conta do proprietário e atribuir `is_admin=true` ao UUID correto.
- Deploy e teste no Netlify.
- Política de privacidade, termos, moderação e suporte.
- Publicidade social: esta versão recolhe um link opcional, mas não publica automaticamente nas redes sociais. Publicação automática requer APIs oficiais, contas de negócio e permissões.
- 500 Kz é apenas contador administrativo; cobrar e receber dinheiro exige um processo de pagamento e reconciliação separado.

## Nota sobre autenticação por telefone
A página já usa Supabase Auth com telefone e palavra-passe, mas a autenticação por telefone depende da configuração de SMS/OTP do teu projeto Supabase. Não invente nem reutilize credenciais. Configura e testa o fluxo antes de anunciar a app ao público.
